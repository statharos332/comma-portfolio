import { urlFor } from "@/sanity/lib/image";

export default function Cases({ projects }: any) {
    return (
        <section
            id="work"
            className="pt-[96px] pb-[96px] min-h-screen px-[clamp(18px,2.4vw,40px)]"
        >

            {/* HEADER - EXACT GRID BALANCE */}
            <div className="grid grid-cols-[minmax(180px,1fr)_auto_minmax(180px,1fr)] items-end gap-[28px] mb-[34px]">

                <span className="text-[11px] text-white/40">
                    02 / Cases
                </span>

                <h2 className="text-[clamp(52px,10.5vw,170px)] leading-[0.8] tracking-[-0.085em] uppercase font-black">
                    Cases
                </h2>

                <span className="text-[11px] text-white/40 text-right">
                    Presentations of selected campaigns
                </span>

            </div>

            {/* GRID */}
            <div className="grid md:grid-cols-2 gap-[4px] pt-[18px] border-t border-white/10">

                {projects?.map((p: any, i: number) => (
                    <article
                        key={i}
                        className="bg-black transition hover:translate-y-[-3px] hover:bg-[#050505]"
                    >

                        {/* MEDIA */}
                        <div className="aspect-video bg-[#2b2b2b] overflow-hidden relative">

                            {p.image && (
                                <img
                                    src={urlFor(p.image).width(1400).url()}
                                    alt={p.title}
                                    className="w-full h-full object-cover transition duration-500 hover:scale-[1.025]"
                                />
                            )}

                        </div>

                        {/* BODY */}
                        <div className="p-[15px_16px_18px]">

                            <h3 className="text-[18px] tracking-[-0.035em] mb-[4px]">
                                {p.title}
                            </h3>

                            <p className="text-white/40 text-[12px] leading-[1.35] mb-[12px] max-w-[560px]">
                                {p.description}
                            </p>

                            {/* TAGS */}
                            {/* ✅ DYNAMIC CATEGORY FROM SANITY */}

                            <div className="flex gap-[8px] flex-wrap mb-[10px]">

                                {p.category && (

                                    <span className="text-[9px] uppercase text-white/50">

                                        {p.category}

                                    </span>

                                )}

                            </div>



                            {/* CTA */}
                            <a
                                href={`/cases/${p.slug?.current}`}
                                className="text-[11px] uppercase tracking-[0.04em] text-white/40 border-b border-white/30 pb-[4px] hover:text-white hover:border-white transition inline-block"
                            >
                                View case
                            </a>

                        </div>

                    </article>
                ))}

            </div>

            {/* CTA */}
            <div className="mt-[42px]">
                <a
                    href="/cases"
                    className="text-[11px] uppercase tracking-[0.045em] text-white/40 underline underline-offset-[5px] hover:text-white transition"
                >
                    All cases →
                </a>
            </div>

        </section>
    );
}