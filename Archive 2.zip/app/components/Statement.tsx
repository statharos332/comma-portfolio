export default function Statement() {
    return (
        <section className="py-[150px] px-[clamp(18px,2.4vw,40px)] text-center">
            <div className="max-w-[880px] mx-auto">
                <div
                    className="text-[30px] leading-[1.02] tracking-[-0.04em] font-bold mb-2"
                    style={{ color: 'var(--fg)' }}
                >
                    3
                </div>
                <h2
                    className="text-[30px] leading-[1.02] tracking-[-0.04em] font-bold max-w-[620px] mx-auto mb-[58px]"
                    style={{ color: 'var(--fg)' }}
                >
                    We combine three essential forces required for modern campaigns.
                </h2>
                <div className="grid grid-cols-3 gap-9 text-center">
                    {[
                        { title: 'Brand Strategy', desc: 'To know what needs to be done.' },
                        { title: 'Creative', desc: 'To know how to do it.' },
                        { title: 'Performance', desc: 'To ensure results are real.' },
                    ].map(({ title, desc }) => (
                        <div key={title}>
                            <h4 className="text-[14px] font-bold tracking-[-0.01em] mb-2" style={{ color: 'var(--fg)' }}>
                                {title}
                            </h4>
                            <p className="text-[12px] leading-[1.35]" style={{ color: 'var(--fg-muted)' }}>
                                {desc}
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
