'use client';

import { useState, useEffect, useCallback } from 'react';
import { urlFor } from '@/sanity/lib/image';

/* ─── Types ─────────────────────────────────────────────── */
interface GalleryItem {
    type: 'image' | 'video';
    image?: any;
    videoUrl?: string;
    caption?: string;
}

interface Fragment {
    _id: string;
    title: string;
    client?: string;
    category?: string;
    coverImage?: any;
    gallery?: GalleryItem[];
}

/* ─── Video embed helper ─────────────────────────────────── */
function toEmbed(url: string): string {
    if (!url) return '';
    // YouTube
    const yt = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/))([a-zA-Z0-9_-]{11})/);
    if (yt) return `https://www.youtube.com/embed/${yt[1]}?autoplay=1&mute=1`;
    // Vimeo
    const vi = url.match(/vimeo\.com\/(\d+)/);
    if (vi) return `https://player.vimeo.com/video/${vi[1]}?autoplay=1&muted=1`;
    return url;
}

/* ─── Modal ──────────────────────────────────────────────── */
function Modal({
    fragment,
    initialIndex,
    onClose,
}: {
    fragment: Fragment;
    initialIndex: number;
    onClose: () => void;
}) {
    const items = fragment.gallery ?? [];
    const [idx, setIdx] = useState(initialIndex);

    const prev = useCallback(() => setIdx(i => (i - 1 + items.length) % items.length), [items.length]);
    const next = useCallback(() => setIdx(i => (i + 1) % items.length), [items.length]);

    useEffect(() => {
        const handler = (e: KeyboardEvent) => {
            if (e.key === 'Escape') onClose();
            if (e.key === 'ArrowLeft') prev();
            if (e.key === 'ArrowRight') next();
        };
        window.addEventListener('keydown', handler);
        return () => window.removeEventListener('keydown', handler);
    }, [onClose, prev, next]);

    // Lock scroll
    useEffect(() => {
        document.body.style.overflow = 'hidden';
        return () => { document.body.style.overflow = ''; };
    }, []);

    const current = items[idx];
    const prevItem = items[(idx - 1 + items.length) % items.length];
    const nextItem = items[(idx + 1) % items.length];

    return (
        <div
            className="fixed inset-0 z-[9999] flex flex-col"
            style={{ background: 'rgba(0,0,0,0.96)' }}
            role="dialog"
            aria-modal="true"
        >
            {/* TOP BAR */}
            <div
                className="flex items-center justify-between px-5 py-3 flex-shrink-0"
                style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}
            >
                <div>
                    <span className="text-[13px] font-medium text-white">{fragment.title}</span>
                    {fragment.client && (
                        <span className="text-[11px] ml-3" style={{ color: 'rgba(255,255,255,0.4)' }}>
                            {fragment.client}
                        </span>
                    )}
                </div>
                <div className="flex items-center gap-4">
                    <span className="text-[11px]" style={{ color: 'rgba(255,255,255,0.35)' }}>
                        {idx + 1} / {items.length}
                    </span>
                    <button
                        onClick={onClose}
                        aria-label="Close"
                        className="w-8 h-8 flex items-center justify-center rounded-full transition"
                        style={{ color: 'rgba(255,255,255,0.6)', background: 'rgba(255,255,255,0.06)' }}
                        onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.14)')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.06)')}
                    >
                        <svg width="16" height="16" viewBox="0 0 28 28" fill="none">
                            <path d="M8.31 17.93c-.37.37-.39 1.03.01 1.41.38.39 1.05.37 1.42.01L14 15.09l4.26 4.26c.38.38 1.03.39 1.41-.01.39-.38.38-1.04.01-1.42L15.42 13.66l4.26-4.26c.38-.38.39-1.03.01-1.41-.38-.4-1.04-.39-1.42-.01L14 12.25 9.74 7.99c-.37-.37-1.04-.39-1.42.01-.4.38-.38 1.04-.01 1.41l4.26 4.26-4.26 4.26Z" fill="currentColor"/>
                        </svg>
                    </button>
                </div>
            </div>

            {/* MAIN CONTENT */}
            <div className="flex-1 flex items-center justify-center relative overflow-hidden px-4 py-4 gap-3">

                {/* PREV GHOST */}
                {items.length > 1 && prevItem?.type === 'image' && prevItem?.image && (
                    <button
                        onClick={prev}
                        aria-label="Previous"
                        className="hidden md:flex flex-shrink-0 w-[80px] items-center justify-center group"
                    >
                        <div className="w-[72px] h-[52px] overflow-hidden rounded opacity-30 group-hover:opacity-55 transition">
                            <img
                                src={urlFor(prevItem.image).width(200).url()}
                                className="w-full h-full object-cover"
                                alt=""
                            />
                        </div>
                    </button>
                )}
                {items.length > 1 && !(prevItem?.type === 'image' && prevItem?.image) && (
                    <div className="hidden md:block w-[80px] flex-shrink-0" />
                )}

                {/* CURRENT */}
                <div className="flex-1 flex items-center justify-center max-h-full">
                    {current?.type === 'video' && current?.videoUrl ? (
                        <div className="w-full max-w-[900px] aspect-video rounded overflow-hidden">
                            <iframe
                                src={toEmbed(current.videoUrl)}
                                className="w-full h-full"
                                allow="autoplay; fullscreen"
                                allowFullScreen
                            />
                        </div>
                    ) : current?.image ? (
                        <img
                            src={urlFor(current.image).width(1600).url()}
                            alt={current.caption ?? ''}
                            className="max-w-full max-h-[calc(100vh-140px)] object-contain rounded"
                            style={{ userSelect: 'none' }}
                        />
                    ) : null}

                    {current?.caption && (
                        <p
                            className="absolute bottom-3 left-1/2 -translate-x-1/2 text-[11px] px-3 py-1 rounded-full"
                            style={{ color: 'rgba(255,255,255,0.45)', background: 'rgba(0,0,0,0.5)' }}
                        >
                            {current.caption}
                        </p>
                    )}
                </div>

                {/* NEXT GHOST */}
                {items.length > 1 && nextItem?.type === 'image' && nextItem?.image && (
                    <button
                        onClick={next}
                        aria-label="Next"
                        className="hidden md:flex flex-shrink-0 w-[80px] items-center justify-center group"
                    >
                        <div className="w-[72px] h-[52px] overflow-hidden rounded opacity-30 group-hover:opacity-55 transition">
                            <img
                                src={urlFor(nextItem.image).width(200).url()}
                                className="w-full h-full object-cover"
                                alt=""
                            />
                        </div>
                    </button>
                )}
                {items.length > 1 && !(nextItem?.type === 'image' && nextItem?.image) && (
                    <div className="hidden md:block w-[80px] flex-shrink-0" />
                )}
            </div>

            {/* BOTTOM NAV */}
            {items.length > 1 && (
                <div
                    className="flex items-center justify-center gap-4 py-3 flex-shrink-0"
                    style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}
                >
                    {/* PREV BUTTON */}
                    <button
                        onClick={prev}
                        aria-label="Previous"
                        className="w-8 h-8 flex items-center justify-center rounded-full transition"
                        style={{ color: 'rgba(255,255,255,0.6)', background: 'rgba(255,255,255,0.06)' }}
                        onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.14)')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.06)')}
                    >
                        <svg width="16" height="16" viewBox="0 0 28 28" fill="none">
                            <path d="M9.64 14c0-.32.1-.58.36-.83l4.63-4.7c.19-.19.41-.28.68-.28.54 0 .98.46.98 1.01 0 .28-.12.54-.32.74L11.94 14l3.97 4.05c.2.21.32.46.32.74 0 .56-.44 1.01-.98 1.01-.27 0-.5-.1-.68-.28L10 14.83C9.74 14.57 9.64 14.31 9.64 14Z" fill="currentColor"/>
                        </svg>
                    </button>

                    {/* DOTS */}
                    <div className="flex gap-[6px]">
                        {items.map((_, i) => (
                            <button
                                key={i}
                                onClick={() => setIdx(i)}
                                aria-label={`Go to ${i + 1}`}
                                className="rounded-full transition-all duration-200"
                                style={{
                                    width: i === idx ? '18px' : '6px',
                                    height: '6px',
                                    background: i === idx ? 'white' : 'rgba(255,255,255,0.25)',
                                }}
                            />
                        ))}
                    </div>

                    {/* NEXT BUTTON */}
                    <button
                        onClick={next}
                        aria-label="Next"
                        className="w-8 h-8 flex items-center justify-center rounded-full transition"
                        style={{ color: 'rgba(255,255,255,0.6)', background: 'rgba(255,255,255,0.06)' }}
                        onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.14)')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.06)')}
                    >
                        <svg width="16" height="16" viewBox="0 0 28 28" fill="none">
                            <path d="M18.25 14c0 .31-.1.57-.36.82l-4.63 4.7c-.18.19-.41.28-.68.28-.54 0-.98-.45-.98-1.01 0-.28.11-.53.32-.74L15.95 14l-3.97-4.05c-.21-.2-.32-.46-.32-.74 0-.55.44-1.01.98-1.01.27 0 .5.1.68.28l4.63 4.7c.25.24.36.5.36.82Z" fill="currentColor"/>
                        </svg>
                    </button>
                </div>
            )}
        </div>
    );
}

/* ─── Grid ───────────────────────────────────────────────── */
const SIZES = [
    'col-span-2 row-span-2',
    'col-span-1 row-span-1',
    'col-span-1 row-span-1',
    'col-span-1 row-span-2',
    'col-span-2 row-span-1',
    'col-span-1 row-span-1',
    'col-span-1 row-span-1',
    'col-span-1 row-span-2',
    'col-span-1 row-span-1',
    'col-span-2 row-span-1',
];

export default function Fragments({ fragments }: { fragments: Fragment[] }) {
    const [open, setOpen] = useState<{ fragment: Fragment; index: number } | null>(null);

    if (!fragments?.length) return null;

    return (
        <>
            <section id="fragments" className="pt-[70px] px-[clamp(18px,2.4vw,40px)]">

                {/* HEADER */}
                <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-5 mb-5">
                    <span className="text-[11px]" style={{ color: 'var(--fg-muted)' }}>01 / Fragments</span>
                    <h2
                        className="text-[clamp(52px,10.5vw,170px)] leading-[0.8] tracking-[-0.085em] uppercase font-black"
                        style={{ color: 'var(--fg)' }}
                    >
                        Archive
                    </h2>
                    <span className="text-right text-[11px]" style={{ color: 'var(--fg-muted)' }}>
                        Campaign pieces, visuals & motion stills
                    </span>
                </div>

                <p className="text-[12px] mb-5 max-w-[460px]" style={{ color: 'var(--fg-muted)' }}>
                    A compact wall of campaign stills, social crops, key visuals and motion moments.
                </p>

                {/* MOSAIC GRID */}
                <div
                    className="grid gap-[3px]"
                    style={{
                        gridTemplateColumns: 'repeat(4, 1fr)',
                        gridAutoRows: 'clamp(80px, 14vw, 160px)',
                    }}
                >
                    {fragments.map((frag, i) => (
                        <button
                            key={frag._id}
                            onClick={() => setOpen({ fragment: frag, index: 0 })}
                            className={`${SIZES[i % SIZES.length]} relative overflow-hidden group cursor-pointer`}
                            style={{ border: '1px solid var(--border)' }}
                            aria-label={`Open ${frag.title}`}
                        >
                            {/* COVER IMAGE */}
                            {frag.coverImage ? (
                                <img
                                    src={urlFor(frag.coverImage).width(600).url()}
                                    alt={frag.title}
                                    className="absolute inset-0 w-full h-full object-cover transition duration-500 group-hover:scale-[1.06]"
                                    style={{ opacity: 0.82 }}
                                />
                            ) : (
                                <div className="absolute inset-0" style={{ background: 'var(--bg-media)' }} />
                            )}

                            {/* HOVER OVERLAY */}
                            <div
                                className="absolute inset-0 flex flex-col justify-end p-[10px] transition duration-300 opacity-0 group-hover:opacity-100"
                                style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.78) 0%, transparent 60%)' }}
                            >
                                <span className="text-[10px] uppercase tracking-[0.05em] text-white font-medium leading-tight">
                                    {frag.title}
                                </span>
                                {frag.client && (
                                    <span className="text-[9px]" style={{ color: 'rgba(255,255,255,0.5)' }}>
                                        {frag.client}
                                    </span>
                                )}
                                {/* gallery count badge */}
                                {frag.gallery && frag.gallery.length > 0 && (
                                    <span
                                        className="absolute top-2 right-2 text-[9px] px-[6px] py-[2px] rounded-full"
                                        style={{ background: 'rgba(0,0,0,0.55)', color: 'rgba(255,255,255,0.7)' }}
                                    >
                                        {frag.gallery.length}
                                    </span>
                                )}
                            </div>
                        </button>
                    ))}
                </div>

            </section>

            {/* MODAL */}
            {open && (
                <Modal
                    fragment={open.fragment}
                    initialIndex={open.index}
                    onClose={() => setOpen(null)}
                />
            )}
        </>
    );
}
