"use client";

export default function Footer() {
    return (
        <footer
            id="footer"
            className="px-[clamp(18px,5.4vw,108px)] pt-[38px] pb-[46px]"
            style={{ borderTop: '1px solid var(--border)', background: 'var(--bg)', color: 'var(--fg)' }}
        >
            <div
                className="max-w-[1540px] mx-auto grid gap-[76px]"
                style={{ gridTemplateColumns: '1.15fr 1fr 1fr' }}
            >
                {/* COL 1 */}
                <div>
                    <span
                        className="block text-[10px] uppercase tracking-[0.045em] mb-3 font-medium"
                        style={{ color: 'var(--fg-muted)' }}
                    >
                        Start your project
                    </span>
                    <a
                        href="mailto:info@comma-abc.com"
                        className="text-[12px] leading-[1.45] underline underline-offset-[5px] transition"
                        style={{ color: 'var(--fg-muted)', textDecorationColor: 'var(--fg-dimmer)' }}
                        onMouseEnter={e => (e.currentTarget.style.color = 'var(--fg)')}
                        onMouseLeave={e => (e.currentTarget.style.color = 'var(--fg-muted)')}
                    >
                        info@comma-abc.com
                    </a>
                    <p className="text-[12px] leading-[1.45] mt-3" style={{ color: 'var(--fg-muted)' }}>
                        Tell us what you want to achieve, what your brand needs next and where communication can work harder.
                    </p>
                </div>

                {/* COL 2 */}
                <div>
                    <span
                        className="block text-[10px] uppercase tracking-[0.045em] mb-3 font-medium"
                        style={{ color: 'var(--fg-muted)' }}
                    >
                        Location
                    </span>
                    <p className="text-[12px] leading-[1.45]" style={{ color: 'var(--fg-muted)' }}>
                        Kifisia Av. 308, 15232 Halandri<br />
                        Athens, Greece<br />
                        Mon–Fri / 9:00–18:00<br />
                        GMT +3
                    </p>
                </div>

                {/* COL 3 */}
                <div>
                    <span
                        className="block text-[10px] uppercase tracking-[0.045em] mb-3 font-medium"
                        style={{ color: 'var(--fg-muted)' }}
                    >
                        Direct contact
                    </span>
                    <div className="text-[12px] leading-[1.45]" style={{ color: 'var(--fg-muted)' }}>
                        <p>T.: +30.210.6857.512</p>
                        <p>F.: +30.210.6857.516</p>
                        {[
                            { href: 'https://www.comma-abc.com/', label: 'comma-abc.com' },
                            { href: 'https://www.instagram.com/comma_agency/', label: 'Instagram' },
                            { href: 'https://www.facebook.com/COMMA.ABC/', label: 'Facebook' },
                            { href: 'https://www.linkedin.com/company/comma-agency/', label: 'LinkedIn' },
                        ].map(({ href, label }) => (
                            <a
                                key={label}
                                href={href}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="block underline underline-offset-[5px] transition"
                                style={{ color: 'var(--fg-muted)', textDecorationColor: 'var(--fg-dimmer)' }}
                                onMouseEnter={e => (e.currentTarget.style.color = 'var(--fg)')}
                                onMouseLeave={e => (e.currentTarget.style.color = 'var(--fg-muted)')}
                            >
                                {label}
                            </a>
                        ))}
                    </div>
                </div>
            </div>
        </footer>
    );
}
